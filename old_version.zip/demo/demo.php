<div class='flex justify-center'>
    <div class='absolute top-20 left-0 right-0 m-auto p-5 bg-red-600 text-white text-xl font-bold rounded-xl shadow-xl text-center w-80'>In der Demo-Version nicht verfügbar.
    <a href='index.php' class='mt-5 flex justify-center'><img src='img/close.png' class='w-7 h-7'></a>
    </div>
</div>