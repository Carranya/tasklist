<?php
echo "<button name='delete' value='" . $dat['id'] . "'><img src='img/delete.png' class='w-7 h-7 hover:opacity-40' title='löschen'></button>";
?>