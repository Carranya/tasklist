<?php
echo "<button name='done' value='" . $dat['id'] . "'><img src='img/done.png' class='w-7 h-7 hover:opacity-40' title='erledigt'></button>";
?>