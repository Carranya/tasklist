<?php
echo "<button><img src='img/close.png' class='w-7 h-7 hover:opacity-40' title='abbrechen'></button>";
?>