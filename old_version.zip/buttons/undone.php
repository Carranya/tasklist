<?php
    echo "<button name='undone' value='" . $dat['id'] . "'><img src='img/close.png' class='w-7 h-7 hover:opacity-40' title='rückgängig'></button>";
?>