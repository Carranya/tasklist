<?php
echo "<button name='pickToEdit' value='" . $dat['id'] . "'><img src='img/edit.png' class='w-7 h-7 hover:opacity-40' title='ändern'></button>";
?>