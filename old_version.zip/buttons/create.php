<?php
echo "<button name='create' value='1'><img src='img/create.png' class='w-7 h-7 hover:opacity-40' title='hinzufügen'></button>";
?>