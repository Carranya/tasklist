<?php
echo "<button name='showAll' value=true><img src='img/showAll.png' class='w-7 h-7 hover:opacity-40' title='Alle Aufgaben anzeigen'></button>";
?>