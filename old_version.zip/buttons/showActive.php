<?php
echo "<a href='index.php'><img src='img/showActive.png' class='w-7 h-7 hover:opacity-40' title='Nur aktive Aufgaben anzeigen'></a>";
?>