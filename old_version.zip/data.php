<?php $data = [

[
'id' => 1,
'task' => 'Bestellung abschicken',
'date' => '2023-01-11',
'active' => 1,
],

[
'id' => 2,
'task' => 'Sitzung vorbereiten',
'date' => '2023-01-11',
'active' => 1,
],

[
'id' => 3,
'task' => 'Herr Müller anrufen',
'date' => '2023-01-12',
'active' => 0,
],

[
'id' => 4,
'task' => 'Paket zur Post bringen',
'date' => '2023-01-12',
'active' => 1,
],

];